from pydantic import BaseModel, ConfigDict, computed_field
from typing import Optional, ClassVar
import specatalog.models.molecules as mol

from specatalog.main import ALLOWED_VALUES as av


class MoleculeModel(BaseModel):
    """
    Pydantic model for creating new :class:`models.Molecule` entries.

    This model defines the minimal required input for creating a molecule in
    the database. It only includes essential molecular metadata; database-
    managed fields such as ``id`` or timestamps are excluded.

    Attributes
    ----------
    molecular_formula : str or None
        Standard chemical formula of the molecule (e.g., "C20H12").
    additional_info : str or None
        Optional free-text field with supplementary information.

    """
    molecular_formula: Optional[str]=None
    additional_info: Optional[str]=None
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class SingleMoleculeModel(MoleculeModel):
    """
    Pydantic model for creating new :class:`mol.SingleMolecule` molecules.

    This subclass of :class:`MoleculeModel` adds fields specific to single-
    molecule entries. The ``model_class`` attribute is fixed to
    :class:`mol.SingleMolecule` and cannot be changed.

    Attributes
    ----------
    model_class : Type
        Always set to :class:`mol.SingleMolecule`. Attempting to assign a different
        class raises a validation error.
    name : str
        Human-readable name of the molecule. Must be unique.

    """
    model_class: ClassVar[mol.SingleMolecule] = mol.SingleMolecule

    name: str


class RPModel(MoleculeModel):
    """
    Pydantic model for creating new :class:`mol.RP` radical-pair molecules.

    This subclass of :class:`MoleculeModel` adds fields specific to
    radical-pair molecules. The ``model_class`` attribute is fixed to
    :class:`mol.RP` and cannot be changed. The ``name`` property is computed
    automatically from the radicals and linker.

    Attributes
    ----------
    model_class : Type
        Always set to :class:`mol.RP`. Attempting to assign a different class
        raises a validation error.
    radical_1 : av.Radicals
        Enumeration specifying the first radical centre.
    linker : av.Linker
        Enumeration specifying the chemical linker connecting the radicals.
    radical_2 : av.Radicals
        Enumeration specifying the second radical centre.
    name : str
        Computed property combining radicals and linker into a
        name (e.g., "TEMPO1-Ph-TEMPO2").
    """
    model_class: ClassVar[mol.RP] = mol.RP

    radical_1: av.Radicals
    linker: av.Linker
    radical_2: av.Radicals
    name_suffix: Optional[str]=None

    @computed_field
    @property
    def name(self) -> str:
        if self.name_suffix == None:
            return f"{self.radical_1.value}-{self.linker.value}-{self.radical_2.value}"
        else:
            return f"{self.radical_1.value}-{self.linker.value}-{self.radical_2.value}-{self.name_suffix}"


class TDPModel(MoleculeModel):
    """
    Pydantic model for creating new :class:`mol.TDP` triplet–doublet–pair
    molecules.

    This subclass of :class:`MoleculeModel` adds fields specific to TDP
    molecules. The ``model_class`` attribute is fixed to :class:`mol.TDP`
    and cannot be changed.

    Attributes
    ----------
    model_class : Type
        Always set to :class:`mol.TDP`. Attempting to assign a different class
        raises a validation error.
    doublet : av.Doublets
        Enumeration specifying the doublet radical centre.
    linker : av.Linker
        Enumeration defining the chemical linker connecting the doublet and
        chromophore.
    chromophore : av.Chromophores
        Enumeration specifying the chromophoric unit in the TDP system.
    name : str
        Computed property combining doublet linker and chromophore into a
        name (e.g., "PDI2-co-TEMPO3").
    """
    model_class: ClassVar[mol.TDP] = mol.TDP

    doublet: av.Doublets
    linker: av.Linker
    chromophore: av.Chromophores
    name_suffix: Optional[str]=None

    @computed_field
    @property
    def name(self) -> str:
        if self.name_suffix == None:
            return f"{self.chromophore.value}-{self.linker.value}-{self.doublet.value}"
        else:
            return f"{self.chromophore.value}-{self.linker.value}-{self.doublet.value}-{self.name_suffix}"


class TTPModel(MoleculeModel):
    """
    Pydantic model for creating new :class:`mol.TTP` triplet–triplet–pair
    molecules.

    This subclass of :class:`MoleculeModel` adds fields specific to TTP
    molecules. The ``model_class`` attribute is fixed to :class:`mol.TTP` and
    cannot be changed. The ``name`` property is computed automatically from the
    triplets and linker.

    Attributes
    ----------
    model_class : Type
        Always set to :class:`mol.TTP`. Attempting to assign a different class
        raises a validation error.
    triplet_1 : av.Chromophores
        Enumeration specifying the first triplet-capable chromophore.
    linker : av.Linker
        Enumeration defining the chemical linker connecting the two triplets.
    triplet_2 : av.Chromophores
        Enumeration specifying the second triplet-capable chromophore.
    name : str
        Computed property combining triplet and linker values into a
        name (e.g., "Perylene-ph-Perylene").
    """
    model_class: ClassVar[mol.TTP] = mol.TTP

    triplet_1: av.Chromophores
    linker: av.Linker
    triplet_2: av.Chromophores
    name_suffix: Optional[str]=None

    @computed_field
    @property
    def name(self) -> str:
        if self.name_suffix == None:
            return f"{self.triplet_1.value}-{self.linker.value}-{self.triplet_2.value}"
        else:
            return f"{self.triplet_1.value}-{self.linker.value}-{self.triplet_2.value}-{self.name_suffix}"
